-- 8. What is the average price for properties with different minimum night requirements?

SELECT Minimum_Nights, AVG(Price) AS Average_Price
FROM airbnb_dataset
GROUP BY Minimum_Nights
ORDER BY Minimum_Nights;
