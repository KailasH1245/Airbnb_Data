-- 14. Which listings have high availability but low review scores?

SELECT Listing_ID, Host_Name, Neighborhood, City, Price, Availability, Review_Scores_Rating
FROM airbnb_dataset
WHERE Availability > 300 AND Review_Scores_Rating < 3.5
ORDER BY Availability DESC, Review_Scores_Rating;
