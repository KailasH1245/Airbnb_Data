-- 5. What is the distribution of room types across different price ranges?

WITH Categorized_Listings AS (
    SELECT Room_Type, 
        CASE 
            WHEN Price < 100 THEN 'Budget (< $100)'
            WHEN Price BETWEEN 100 AND 200 THEN 'Mid-Range ($100-$200)'
            WHEN Price BETWEEN 200 AND 300 THEN 'Premium ($200-$300)'
            ELSE 'Luxury (> $300)'
        END AS Price_Category
    FROM airbnb_dataset
)
SELECT Room_Type, Price_Category, COUNT(*) AS Listings
FROM Categorized_Listings
GROUP BY Room_Type, Price_Category
ORDER BY Listings DESC;


