-- 4. Which neighborhood in a specific city (e.g., New York) has the highest average rating?

SELECT TOP 1 Neighborhood, AVG(Review_Scores_Rating) AS Average_Rating
FROM airbnb_dataset
WHERE City = 'New York'
GROUP BY Neighborhood
ORDER BY Average_Rating DESC;
