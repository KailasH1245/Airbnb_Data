-- 13. Which hosts manage listings with the highest average ratings?

SELECT TOP 10 Host_ID, Host_Name, AVG(Review_Scores_Rating) AS Average_Rating
FROM airbnb_dataset
GROUP BY Host_ID, Host_Name
ORDER BY Average_Rating DESC;