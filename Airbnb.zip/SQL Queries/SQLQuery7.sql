-- 7. Which hosts have the most listings, and how well are their properties rated?

SELECT TOP 10 Host_ID, Host_Name, COUNT(*) AS Total_Listings, AVG(Review_Scores_Rating) AS Average_Rating
FROM airbnb_dataset
GROUP BY Host_ID, Host_Name
ORDER BY Total_Listings DESC;
