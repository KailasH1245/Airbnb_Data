-- 1. Which city has the highest average price per listing?

SELECT TOP 1 City, AVG(Price) AS Average_Price
FROM airbnb_dataset
GROUP BY City
ORDER BY Average_Price DESC;
