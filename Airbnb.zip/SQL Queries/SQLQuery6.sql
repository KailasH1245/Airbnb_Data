-- 6.  What is the relationship between availability and review scores? 
--     Do properties with higher availability tend to have lower ratings?

SELECT Availability, AVG(Review_Scores_Rating) AS Average_Rating
FROM airbnb_dataset
GROUP BY Availability
ORDER BY Availability DESC;
