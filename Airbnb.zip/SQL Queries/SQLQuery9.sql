-- 9. Which property types have the highest average review scores?

SELECT Property_Type, AVG(Review_Scores_Rating) AS Average_Rating
FROM airbnb_dataset
GROUP BY Property_Type
ORDER BY Average_Rating DESC;
