-- 12. Which cities have the most budget-friendly listings?

SELECT City, COUNT(*) AS Budget_Listings
FROM airbnb_dataset
WHERE Price < 100
GROUP BY City
ORDER BY Budget_Listings DESC;