-- 2. Which property type is most common in each city?

SELECT City, Property_Type, COUNT(*) AS Total_Listings
FROM airbnb_dataset
GROUP BY City, Property_Type
ORDER BY City, Total_Listings DESC;