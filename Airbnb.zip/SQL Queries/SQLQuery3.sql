-- 3. What is the average review score for properties with over 100 reviews?

SELECT AVG(Review_Scores_Rating) AS Average_Score
FROM airbnb_dataset
WHERE Number_of_Reviews > 100;
