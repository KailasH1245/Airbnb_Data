-- 11. Which neighborhoods have the most available listings?

SELECT Neighborhood, COUNT(*) AS Available_Listings
FROM airbnb_dataset
WHERE Availability > 0
GROUP BY Neighborhood
ORDER BY Available_Listings DESC;
